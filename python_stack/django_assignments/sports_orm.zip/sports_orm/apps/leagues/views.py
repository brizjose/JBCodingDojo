from django.shortcuts import render, redirect, HttpResponse
from django.db.models import Count
from .models import League, Team, Player
# from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
	}
	return render(request, "leagues/index.html", context)

#Part I

# 1. all baseball leagues
def baseball(request):
	return render(request, "leagues/show.html", {'leagues':League.objects.filter(sport="Baseball")})
# 2. all women's leagues
def womens(request):
	return render(request, "leagues/show.html", {'leagues':League.objects.filter(name__contains="omen")})
# 3. all hockey leagues
def hockey(request):
	return render(request, "leagues/show.html", {'leagues':League.objects.filter(name__contains="ockey")})
# 4. all leagues that aren't football
def notfootball(request):
	return render(request, "leagues/show.html", {'leagues':League.objects.exclude(name__contains="ootball")})
# 5. all leagues calling themselves conferences
def conference(request):
	return render(request, "leagues/show.html", {'leagues':League.objects.filter(name__contains="onference")})
# 6. all leagues in the Atlatnic region
def atlantic(request):
	return render(request, "leagues/show.html", {'leagues':League.objects.filter(name__contains="lantic")})
# 7. all teams based in dallas
def dallas(request):
	return render(request, "leagues/teams.html", {'teams':Team.objects.filter(location="Dallas")})
# 8. all teams named raptors
def raptors(request):
	return render(request, "leagues/teams.html", {'teams':Team.objects.filter(team_name__contains="aptor")})
# 9. all teams whose location includes city
def city(request):
	return render(request, "leagues/teams.html", {'teams':Team.objects.filter(location__contains="ity")})
# 10. all teams whose name begins with T
def t(request):
	return render(request, "leagues/teams.html", {'teams':Team.objects.filter(team_name__startswith="T")})
# 11. all teams sorted by location
def location(request):
	return render(request, "leagues/teams.html", {'teams':Team.objects.order_by('location')})
# 12. all teams sorted name in reverse order
def name(request):
	return render(request, "leagues/teams.html", {'teams':Team.objects.order_by('-team_name')})
# 13. all players with last name cooper
def cooper(request):
	return render(request, "leagues/player.html", {'players':Player.objects.filter(last_name__contains="ooper")})
# 14. all players with first name joshua
def josh(request):
	return render(request, "leagues/player.html", {'players':Player.objects.filter(first_name__contains="oshua")})
# 15. all players with last name cooper, except joshua
def notjosh(request):
	return render(request, "leagues/player.html", {'players':Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua")})
# 16. all players with first name either alexander or wyatt
def alexwyatt(request):
	return render(request, "leagues/player.html", {'players':Player.objects.filter(first_name="Alexander")|Player.objects.filter(first_name="Wyatt").order_by('last_name')})

#Part II

# 1. all teams in Atlantic soccer conference
def atlanticsoccer(request):
	league = League.objects.filter(name__contains="occer")
	context = {
		'leagues':league
	}
	return render(request, "leagues/show.html", context)
# 2. all current players in the Boston Penguins
def penguinplayers(request):
	team_players = Team.objects.filter(team_name__contains="enguins")[0].curr_players.all()
	context = {
		'players': team_players
	}
	return render(request, "leagues/player.html", context)

# 3. all current players in the International Collegiate Baseball Conference
def icbc(request):
	# team_list = League.objects.filter(name__contains="International Collegiate Baseball Conference")[0].teams.all()
	# team_ids = []
	# players = []
	# for i in range(len(team_list)):
	# 	team_ids.append(team_list[i].id)
	# 	players.extend(team_list[i].curr_players.all())

	# league = League.objects.filter(name="International Collegiate Baseball Conference")
	# players = Player.objects.filter(curr_team__league=league)

	players = Player.objects.filter(curr_team__league=League.objects.filter(name="International Collegiate Baseball Conference"))

	context = {
		'players': players
	}	
	return render(request, "leagues/player.html", context)

# 4. all (current) players in the American Conference of Amateur Football with last name "Lopez"
def acaf(request):
	# team_list = League.objects.filter(name__contains="American Conference of Amateur Football")[0].teams.all()
	# team_ids = []
	# players = []
	# for i in range(len(team_list)):
	# 	team_ids.append(team_list[i].id)
	# 	players.extend(team_list[i].curr_players.filter(last_name__contains="Lopez"))

	players = Player.objects.filter(curr_team__league=League.objects.filter(name="American Conference of Amateur Football")).all().filter(last_name="Lopez")

	context = {
		'players': players
	}	
	return render(request, "leagues/player.html", context)

# 5. all football players
def football_players(request):
	# team_list = League.objects.filter(name__contains="ootball")[0].teams.all()
	# team_ids = []
	# players = []
	# for i in range(len(team_list)):
	# 	team_ids.append(team_list[i].id)
	# 	players.extend(team_list[i].curr_players.all())
	
	players = Player.objects.filter(curr_team__league=League.objects.filter(name__contains="Football"))	
	
	context = {
		'players': players
	}	
	return render(request, "leagues/player.html", context)

# 6. all teams with a (current) player named "Sophia"
def sophia(request):
	# players = Player.objects.filter(first_name__contains="ophia").all()
	# team_list = []
	# for i in range(len(players)):
	# 	team_list.append(players[i].curr_team)

	team_list = Team.objects.filter(curr_players__first_name="Sophia")

	context = {
		'teams' : team_list
	}
	return render(request, "leagues/teams.html", context)

# 7. all leagues with a (current) player named "Sophia"
def sophia_league(request):
	# players = Player.objects.filter(first_name__contains="ophia").all()
	# team_ids = []
	# leagues = []
	# for i in range(len(players)):
	# 	team_ids.append(players[i].curr_team.id)
	# 	leagues.append(players[i].curr_team.league)
	# print team_ids
	# print leagues
	
	leagues = League.objects.filter(teams__curr_players__first_name="Sophia")  #GOOD EXAMPLE OF HOW DUNDER JUMPS TABLE TO TABLE

	context = {
		'leagues' : leagues
	}
	return render(request, "leagues/leagues.html", context)

# 8. everyone with the last name "Flores" who DOESN'T (currently) play for the Washington Roughriders
def flores(request):
	# team = Team.objects.get(team_name__contains="oughriders").id
	# players = Player.objects.filter(last_name__contains="Flores").exclude(curr_team=Team.objects.get(id=team))
	
	players = Player.objects.exclude(curr_team__team_name="Washington Roughriders").filter(last_name="Flores")
	
	context = {
		'players': players
	}	
	return render(request, "leagues/player.html", context)

# 9. all teams, past and present, that Samuel Evans has played with
def samevans(request):
	# teams = Player.objects.get(first_name__contains="Sam", last_name__contains="Evans").all_teams.all()
	
	teams = Team.objects.filter(all_players__first_name="Samuel", all_players__last_name="Evans")
	
	context = {
		'teams':teams
	}
	return render(request, "leagues/teams.html", context)

# 10. all players, past and present, with the Manitoba Tiger-Cats
def tiger_cats(request):
	players = Team.objects.get(team_name__contains="iger-C").all_players.all()
	
	players = Player.objects.filter(all_teams__team_name="Tiger-Cats")

	context = {
		'players': players
	}	
	return render(request, "leagues/player.html", context)

# 11. all players who were formerly (but aren't currently) with the Wichita Vikings
def former_vikings(request):
	# players = Team.objects.get(team_name__contains="ikings").all_players.all().exclude(curr_team=Team.objects.get(team_name__contains='ikings'))
	
	players = Player.objects.exclude(curr_team__team_name="Vikings").filter(all_teams__team_name="Vikings")
	
	context = {
		'players': players
	}	
	return render(request, "leagues/player.html", context)

# 12. every team that Jacob Gray played for before he joined the Oregon Colts
def jacob_gray(request):

	#first get all teams where his name appears, then exclude his current team:

	teams = Player.objects.get(first_name__contains="acob", last_name__contains="ray").all_teams.exclude(team_name__contains="olts")
	
	context = {
		'teams':teams
	}
	return render(request, "leagues/teams.html", context)

# 13. everyone named "Joshua" who has ever played in the Atlantic Federation of Amateur Baseball Players
def joshuall(request):	
	# teams = League.objects.get(name="Atlantic Federation of Amateur Baseball Players").teams.all() 
	# print teams
	# players = []
	# for i in range(len(teams)):
	# 	players.extend(Team.objects.get(id=teams[i].id).all_players.all().filter(first_name__contains="oshua"))
	
	# players = Team.objects.filter(league__name="Atlantic Federation of Amateur Baseball Players").all_players.filter(first_name="Joshua") - did not work
	
	players = Player.objects.filter(all_teams__league__name="Atlantic Federation of Amateur Baseball Players").filter(first_name="Joshua").order_by('last_name')

	context = {
		'players': players
	}	
	return render(request, "leagues/player.html", context)

# 14. all teams that have had 12 or more players, past and present. (HINT: Look up the Django annotate function.)
def morethan12(request):
	# teams = Team.objects.annotate(player_count=Count('all_players'))
	# team_list = []
	# for i in range(len(teams)):
	# 	if teams[i].player_count > 11:
	# 		team_list.append(teams[i])
	
	team_list = Team.objects.annotate(player_count=Count('all_players')).filter(player_count__gte=12).order_by('-player_count')

	context = {
		'teams' : team_list
	}
	return render(request, 'leagues/team_list.html', context)

# 15. all players and count of teams played for, sorted by the number of teams they've played for
def allinall(request):
	# players = Player.objects.annotate(team_count=Count('all_teams'))
	# players_list = players.order_by('-team_count')
	
	players_list = Player.objects.annotate(team_count=Count('all_teams')).order_by('-team_count')
	
	context = {
		'players': players_list
	}	
	return render(request, "leagues/allinall.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")